Units: millimetres. Exported from keyboard_AcidAlloy.blend, evaluated mesh at rest.
13 keycaps SW03-SW15. STL contains geometry only, without printed graphics or colours.
These are source model exports. Check slicing, wall thickness and fit before printing.
